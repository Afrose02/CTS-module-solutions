// Java Program 8
// This is a placeholder program for problem 8.
public class Program8 {
    public static void main(String[] args) {
        System.out.println("Executing Program 8");
    }
}