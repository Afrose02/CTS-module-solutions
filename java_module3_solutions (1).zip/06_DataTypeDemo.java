public class DataTypeDemo {
    public static void main(String[] args) {
        int a = 10;
        float b = 10.5f;
        double c = 20.99;
        char d = 'A';
        boolean e = true;

        System.out.println("Integer: " + a);
        System.out.println("Float: " + b);
        System.out.println("Double: " + c);
        System.out.println("Char: " + d);
        System.out.println("Boolean: " + e);
    }
}