// Java Program 36
// This is a placeholder program for problem 36.
public class Program36 {
    public static void main(String[] args) {
        System.out.println("Executing Program 36");
    }
}